import React from 'react';
import Tags from './Tags';
import modelImage from '../image.png'

import '../Header.css';

const Header = () => {
  return (
    <div className="Right-container">
     <div className='nav'><header class="navbar">
  <h1 class="logo">ZARE</h1>
  
    <ul>
      <li><i class="bi bi-bag"></i></li>
      <li><i class="bi bi-person"></i></li>
      <li><i class="bi bi-list"></i></li>
    </ul>
</header></div>
      <div className="text-content">
        <h2>We're unveiling Chic,<br />your ultimate fashion destination</h2>
        <div className='discount'>
        <img src={modelImage} alt="srujana" />
        <p>Explore an extensive collection, curated to redefine your wardrobe. Elevate your fashion quotient effortlessly.</p>
        </div>
        
      </div>
      <Tags />
      
    </div>
  );
};

export default Header;
